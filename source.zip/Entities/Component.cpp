//#ifndef COMPONENT_CPP
//#define COMPONENT_CPP

#include "Component.hpp"

GLuint Component::current_id;

//#endif