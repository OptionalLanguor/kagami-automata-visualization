//#ifndef KAGAMI_ENTITIES_ENTITY_CPP_
//#define KAGAMI_ENTITIES_ENTITY_CPP_

#include "Entity.hpp"

GLuint Entity::current_id;

//#endif